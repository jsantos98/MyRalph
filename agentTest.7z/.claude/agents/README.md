# Software Development Agent Suite

A coordinated team of specialized AI agents for product software development, designed to work together following industry best practices, agile methodologies, and clean architecture principles.

## Overview

This agent suite implements a complete software development lifecycle with clear role separation, workflow orchestration, and quality gates. Each agent has a specialized focus and works together to deliver high-quality software.

## Team Structure

```
Product Owner (User)
        │
        ▼
Senior Project Manager (PM)
        │
        ├──► Senior UX Designer (UX) ──┐
        │                              │
        ├──► Senior Software Architect (SA) ────────┐
        │                                          │
        └──► Senior QA Tester (QA)                  │
                                                   │
        ┌──────────────────────────────────────────┘
        │
        ▼
    Implementation
        │
        ├──► Senior Backend Developer (BE)
        ├──► Senior Frontend Developer (FE)
        └──► Senior Database Developer (DB)
```

## Agent Registry

| Agent | File | Role | Expertise |
|-------|------|------|-----------|
| **PM** | `project-manager.md` | Orchestrator | Requirements, coordination, Asana, workflow |
| **SA** | `software-architect.md` | Technical Lead | Architecture, code reviews, task breakdown |
| **BE** | `backend-developer.md` | Backend Specialist | APIs, security, Node.js/C#, testing |
| **FE** | `frontend-developer.md` | Frontend Specialist | React/Angular, responsive design, accessibility |
| **DB** | `database-developer.md` | Database Specialist | Schema design, optimization, migrations |
| **UX** | `ux-designer.md` | Design Specialist | Mockups, Figma, UI/UX, accessibility |
| **QA** | `qa-tester.md` | Quality Specialist | Test automation, integration testing, coverage |

## Workflow

### 1. Feature Request (PO → PM)
```
Product Owner provides feature requirements
        │
        ▼
PM clarifies requirements, business value, intent
```

### 2. Requirements & Design (PM → UX + SA)
```
┌─────────────────────────────────────┐
│ If UI changes needed:               │
│   PM coordinates with UX            │
│   UX creates mockups                │
│   PO approves mockups               │
└─────────────────────────────────────┘
        │
        ▼
PM works with SA for technical breakdown
SA breaks down into skill-scoped tasks
```

### 3. Implementation (SA orchestrates)
```
SA creates feature branch
        │
        ▼
For each task (priority/dependency order):
        │
        ├──► Spawn specialist (BE/FE/DB)
        ├──► Specialist implements with clean context
        ├──► SA performs code review
        ├──► Request changes if needed
        └────► Approve and continue
```

### 4. Quality Assurance (QA + SA)
```
QA creates integration tests
        │
        ▼
SA validates integration tests
        │
        ▼
Tests must cover full functionality
Coverage must be 80%+
```

### 5. Delivery (SA → PO)
```
SA validates final PR
        │
        ▼
Prepare validation environment
        │
        ▼
PO accepts/rejects feature
```

## Agent Coordination Protocol

### Starting a New Feature

**Invoke PM Agent:**
```
Start a new feature implementation.

Feature: [Feature description]
Business value: [Why this matters]
Success criteria: [How we measure success]
Constraints: [Any limitations]

Please clarify requirements and coordinate with the team.
```

### PM Orchestration

The PM agent will:
1. Ask clarifying questions about requirements
2. Coordinate with UX if UI changes are needed
3. Work with SA to break down tasks
4. Create Asana tasks and sections
5. Monitor progress throughout implementation

### Clean Context Protocol

All specialist agents (BE, FE, DB, UX, QA) start with **clean memory context** for each task:

```markdown
Task Assignment: [Task name]
Assigned to: [Agent]
Context: [Brief context]
Acceptance Criteria: [Clear criteria]
Dependencies: [Any dependencies]

Starting with clean context...
```

### Code Review Process

SA reviews every implementation before merging:

```markdown
Code Review: [Task name]
Reviewed by: SA
Status: [Approved/Changes Requested]

Checklist:
- [x] Follows architecture patterns
- [x] Proper error handling
- [x] Security best practices
- [x] Tests with 80%+ coverage
- [x] Code is maintainable
- [x] Git commit message clear

Comments: [Specific feedback]
```

## Quality Gates

| Gate | Owner | Criteria |
|------|-------|----------|
| Requirements clarity | PM | Unambiguous, testable |
| UX approval | PO | Mockups approved |
| Architecture review | SA | Patterns applied, scalable |
| Implementation review | SA | Code quality, tests |
| Integration tests | QA + SA | Full functionality covered |
| Test coverage | QA | 80%+ minimum |
| Final PR | SA | Ready for PO review |
| PO acceptance | PO | Feature works as specified |

## Git Workflow

### Branch Management
```bash
# SA creates feature branch
git checkout -b feature/[feature-name]
git push -u origin feature/[feature-name]

# Specialists commit their work
git add [files]
git commit -m "feat: [description]

- Implemented [what]
- Added tests for [scenarios]
- Handles [edge case]

Co-Authored-By: Claude (GLM-4.7) <noreply@anthropic.com>"

# SA merges after review
git checkout main
git merge feature/[feature-name]
git push
```

### Commit Message Format
```
type(scope): subject

- Implementation notes
- Test coverage
- Edge cases handled

Co-Authored-By: Claude (GLM-4.7) <noreply@anthropic.com>
```

Types: `feat`, `fix`, `refactor`, `test`, `docs`, `chore`

## Asana Integration

The PM agent manages Asana tasks:

```
Feature Section: [Feature Name]
├── Task: [Task 1] - [Status]
├── Task: [Task 2] - [Status]
└── Task: [Task 3] - [Status]

Comments:
- [Task completed with summary]
- [Blocker encountered]
- [Milestone achieved]
```

## Best Practices

### For All Agents
✅ Start each task with clean context
✅ Commit work after each validated task
✅ Ask questions when requirements are unclear
✅ Follow defined patterns and best practices
❌ Don't make assumptions about requirements
❌ Don't skip code reviews or tests

### For Orchestration (PM, SA)
✅ Break tasks into single-responsibility units
✅ Maintain clear dependency tracking
✅ Enforce quality gates
✅ Communicate progress clearly
❌ Don't create tasks requiring multiple expertise areas

### For Specialists (BE, FE, DB, UX, QA)
✅ Focus on your area of expertise
✅ Deliver tested, reviewed work
✅ Commit frequently with clear messages
✅ Document decisions and deviations
❌ Don't work outside your expertise scope

## Quick Start

### To Start a New Feature

1. **Invoke the PM agent** with your feature requirements
2. **PM clarifies requirements** and coordinates with UX/SA
3. **SA breaks down tasks** and creates feature branch
4. **Specialists implement** following the orchestration
5. **SA reviews** each implementation
6. **QA validates** with integration tests
7. **PO reviews** and accepts the feature

### Example Invocation

```markdown
I want to implement a user authentication system with:
- Email/password registration
- Email verification
- Password reset flow
- JWT-based sessions
- Remember me functionality

Business value: Enable user accounts and personalized experience
Success criteria: Users can register, verify email, login, and reset password
```

## Agent File Locations

All agent definitions are in `.claude/agents/`:

```
.claude/
├── agents/
│   ├── README.md (this file)
│   ├── project-manager.md
│   ├── software-architect.md
│   ├── backend-developer.md
│   ├── frontend-developer.md
│   ├── database-developer.md
│   ├── ux-designer.md
│   └── qa-tester.md
└── ...
```

---

**Version**: 1.0.0
**Last Updated**: 2025-01-29
**Maintained by**: Product Owner & Development Team
