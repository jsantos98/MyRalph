# Agent Invocation Quick Reference

Quick guide for invoking the software development agents in your workflow.

## Starting a New Feature

Invoke the **Project Manager (PM)** to begin:

```
I need to implement a new feature. Here are the requirements:

[Describe your feature, business value, success criteria]

Please act as the Senior Project Manager and coordinate this feature implementation.
```

## Direct Agent Invocations

### Project Manager (PM)
**Use for**: Starting features, requirements clarification, team coordination

```
Act as the Senior Project Manager. I need to:

[Task description]

Please clarify requirements, coordinate with UX/SA, and manage the implementation.
```

### Software Architect (SA)
**Use for**: Architecture design, code reviews, task breakdown

```
Act as the Senior Software Architect. I need you to:

[Task description - e.g., design architecture, review code, break down tasks]

Please provide technical guidance and architecture decisions.
```

### Backend Developer (BE)
**Use for**: API development, business logic, server-side implementation

```
Act as the Senior Backend Developer. Task:

[Task description with acceptance criteria]

Starting with clean context, implement this backend feature.
```

### Frontend Developer (FE)
**Use for**: UI implementation, React/Angular components, responsive design

```
Act as the Senior Frontend Developer. Task:

[Task description with UX mockup reference]

Starting with clean context, implement this frontend component.
```

### Database Developer (DB)
**Use for**: Schema design, migrations, query optimization

```
Act as the Senior Database Developer. Task:

[Task description with data model requirements]

Starting with clean context, design and implement this database schema.
```

### UX Designer (UX)
**Use for**: UI mockups, user flows, design specifications

```
Act as the Senior UX Designer. I need designs for:

[Feature description, user goals, requirements]

Please create mockups and design specifications.
```

### QA Tester (QA)
**Use for**: Test creation, test automation, integration testing

```
Act as the Senior QA Tester. I need tests for:

[Feature description, acceptance criteria]

Starting with clean context, create comprehensive tests.
```

## Workflow Templates

### Template 1: New Feature with UI Changes

```
I want to implement: [Feature Name]

Requirements:
- [Requirement 1]
- [Requirement 2]
- [Requirement 3]

Business Value: [Why this matters]

Success Criteria: [How we measure success]

This feature requires UI changes.

Please coordinate as the Senior Project Manager.
```

### Template 2: New Feature (Backend Only)

```
I want to implement: [Feature Name]

Requirements:
- [API endpoint specifications]
- [Business logic requirements]
- [Database needs]

This is a backend-only feature (no UI changes).

Please coordinate as the Senior Project Manager.
```

### Template 3: Bug Fix

```
I need to fix a bug:

Bug Description: [What's wrong]
Expected Behavior: [What should happen]
Actual Behavior: [What's happening]
Steps to Reproduce: [How to trigger it]

Please coordinate the fix as the Senior Project Manager.
```

### Template 4: Code Review Request

```
I need a code review for: [Component/Feature]

Files Changed:
- [file1.ts]
- [file2.ts]
- [file3.ts]

Description: [What was changed]

Please review as the Senior Software Architect.
```

### Template 5: Test Coverage

```
I need tests for: [Feature/Component]

Current Coverage: [X%]
Target Coverage: [80%+]

Scenarios to test:
- [Happy path]
- [Edge case 1]
- [Edge case 2]
- [Error case]

Please create tests as the Senior QA Tester.
```

## Agent Handoff Examples

### PM → SA (Task Breakdown)
```
@SA, I have clarified requirements for [Feature].

Requirements Summary:
- [Clarified requirements]
- [Acceptance criteria]
- [Constraints]

Please break this down into skill-scoped tasks for implementation.
```

### SA → BE (Backend Task)
```
@BE, here's your task:

**Task**: [Task name]
**Feature**: [Feature name]
**Acceptance Criteria**: [criteria]
**API Contract**: [spec]
**Dependencies**: [any dependencies]

Starting with clean context, implement this backend feature.
```

### SA → FE (Frontend Task)
```
@FE, here's your task:

**Task**: [Task name]
**Feature**: [Feature name]
**Acceptance Criteria**: [criteria]
**Mockups**: [Figma link/reference]
**API Integration**: [endpoints to call]
**Dependencies**: [any dependencies]

Starting with clean context, implement this frontend component.
```

### BE/FE → SA (Code Review Request)
```
@SA, I've completed my task: [Task name]

**Changes Made**: [summary]
**Files Modified**: [list]
**Tests Added**: [list]
**Coverage**: [percentage]

Please review my implementation.
```

## Common Commands

### Git Commands
```bash
# SA creates feature branch
git checkout -b feature/[name]
git push -u origin feature/[name]

# Specialist commits work
git add [files]
git commit -m "feat: [description]

- Implemented [what]
- Added tests for [scenarios]
- Handles [edge case]

Co-Authored-By: Claude (GLM-4.7) <noreply@anthropic.com>"

# SA merges after review
git checkout main
git merge feature/[name]
git push
```

### Asana Commands (PM)
```
# Create feature section
Section: [Feature Name]
- Task: [Task 1] - Assign to [Agent]
- Task: [Task 2] - Assign to [Agent]
- Task: [Task 3] - Assign to [Agent]

# Update status
Comment: "[Summary of completed work]"
Status: To Do → In Progress → Complete
```

## Clean Context Reminder

**When invoking BE, FE, DB, UX, or QA agents**, they will automatically:

1. Acknowledge the task assignment
2. Confirm they're starting with clean context
3. Read only necessary files for this task
4. Ask clarifying questions if needed

Example response:
```
I'm starting the task: "[Task name]"

Starting with clean context. Reading only:
- [file1]
- [file2]
- [file3]

Ready to implement. Questions:
- [Question 1]
- [Question 2]
```

---

**Tip**: Always start with the PM agent for new features. The PM will coordinate with other agents as needed.
